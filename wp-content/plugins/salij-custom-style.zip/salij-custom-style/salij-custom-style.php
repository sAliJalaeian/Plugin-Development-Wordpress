<?php
/**
 * Plugin Name: salij custom style
 */

defined('ABSPATH') || exit;

define('SALIJ_CUSTOM_STYLE_VIEW', plugin_dir_path(__FILE__) . 'view/');

function salij_custom_style_menu_content(): void
{
    include(SALIJ_CUSTOM_STYLE_VIEW . 'custom_style_page.php');
}

function salij_custom_style_menu(): void
{
    add_menu_page(
        'استایل سفارشی',
        'استایل سفارشی',
        'manage_options',
        'salij_custom_style',
        'salij_custom_style_menu_content'
    );
}

add_action('admin_menu', 'salij_custom_style_menu');

